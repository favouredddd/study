var Taf  = require("taf-rpc").server;
var TRom = require("./NodeJsCommImp.js").TRom;

var svr = Taf.createServer(TRom.NodeJsCommImp);
svr.start({
    name     : "TRom.NodeJsTestServer.AdminObjAdapetr",
    servant  : "TRom.NodeJsTestServer.AdminObj",
    endpoint : "tcp -h 127.0.0.1 -p 14002 -t 10000",
    protocol : "taf",
	maxconns : 200000
});

console.log("server started.");
